#include <iostream>
#include <stdio.h>
#include <list>
#include <string.h>
using namespace std;

#define MOD 101
#define SIZE 101

int hash_func(char str[])
{
    int i,len=strlen(str);
    int hash=0;
    for(i=0; i<len; i++)
    {
        hash += str[i]^i * 27;
        hash %= MOD;
    }
    return hash;
}

class symbolInfo
{
public:
    char *name;
    char *type;
//your code
};

class symbolTable
{
public:
    list <symbolInfo> stable[SIZE];
    //your code
};




int main()
{
    symbolTable symtab;
    //your code, variable declaration
    char temp[SIZE];
    gets(temp); //input from file
    char first = temp[0];
    while(true)
    {
        switch(first)
        {
            case 'I':		//insert
                //your code
                printf("Inserted\n");
                break;
            case 'D':		//delete
                //your code
                printf("Deleted\n");
                break;
            case 'L': //Search Info
                //your code
                printf("Searched\n");
                break;
            case 'P': //show symbol table
                //your code
                printf("Printed\n");
                break;
            default:
                printf("Wrong input\n");
                break;

        }
        gets(temp); //input
        first = temp[0];
    }

    return 0;
}
